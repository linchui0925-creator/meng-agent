# @meng/plugin-dsh-purge 0.3.2

把 **dsh-purge-community 1.7.20** 装配进梦。上游源码固定在插件包内的
`vendor/dsh-purge/`，适配器只做宿主能力映射，不重写业务实现。

## 现在能用的内容

| 上游能力 | 梦适配状态 |
|---|---|
| 原版 Purge 面板 | 🟢 原版 client 原样装入设置页 |
| 新会话首页入口 | 🟢 输入建议下方显示摘要卡 |
| 右侧插件栏 | 🟢 显示提示词、规则、技能和红队摘要 |
| 状态 / 提示词 / 规则 / 技能 / 演练台 / 更多 | 🟢 六个页签可打开 |
| 上游规则库 | 🟢 `rules.js` 原样 import，写入插件数据目录 |
| 技能库 | 🟢 可导入、列表、读取、保存和删除技能；公开发行包不内置攻击技能 |
| 运行时探针 | 🟢 一次性暗号进入梦的系统提示 |
| 审计与快照 | 🟢 模式、规则、技能、红队写操作都有记录 |
| RedTeam SQLite 事实库 | 🟢 `store-core.js` 原样 import |
| 上游 RedTeam 工具 | 🟢 64 个 `redteam_*` 工具注册进梦 |
| `/dsh-purge/*` 兼容路由 | 🟢 原版面板直接使用 |
| `/redteam/api` | 🟢 原版演练台直接使用 |
| DSH 源码 86 条宿主补丁 | 🔴 不适用：梦不修改宿主源码 |
| Electron / ASAR 换包 | 🔴 不适用 |
| DSH 自动更新 / 卸载 / 桌面重启 | 🔴 不适用，交给梦插件市场 |
| DSH agent preset 菜单 / 宿主补丁 tuning | 🔴 不适用：梦没有 DSH preset 与源码补丁平面 |

## 数据目录

默认：`<MENG_DATA_DIR>/dsh-purge/`

```text
dsh-purge/
├── prompt-inject.md       用户正文（首次启动从上游默认正文播种）
├── state.json             模式与排除会话
├── rules/                 上游规则库
├── skills/                上游技能库
├── redteam/               RedTeam SQLite 与靶标文件
├── audit.jsonl            梦适配层审计
├── snapshots/             模式快照
└── probe.json             运行时探针
```

## 工具

梦原生适配工具：

- `dsh_purge_probe`
- `dsh_purge_status`
- `dsh_purge_mode`
- `dsh_purge_audit`
- `dsh_purge_rollback`
- `dsh_purge_rules`
- `dsh_purge_skills`
- `dsh_purge_redteam`

另有 64 个上游 `redteam_*` 工具，直接在梦的工具注册表里出现。

## Web / HTTP

Web op：

- `dshPurge.status`
- `dshPurge.mode`
- `dshPurge.probe`
- `dshPurge.audit`
- `dshPurge.rollback`
- `dshPurge.rules`
- `dshPurge.skills`
- `dshPurge.redteam`
- `dshPurge.adapters`

兼容 HTTP：

- `/dsh-purge/status`
- `/dsh-purge/override`
- `/dsh-purge/rules`
- `/dsh-purge/skills`
- `/dsh-purge/probe`
- `/dsh-purge/audit`
- `/dsh-purge/drill-grant`
- `/redteam/api`

DSH 专属的 `/dsh-purge/apply`、`/revert`、`/uninstall`、`/restart` 返回明确的
“梦不适用”，不会假装成功。

## 构建和验收

```bash
npm run build --prefix plugins/dsh-purge
npm run test:dsh-purge
```

验收覆盖：原版面板生命周期、64 个上游工具注册与调用、规则、技能导入、
SQLite 红队库、HTTP 兼容路由、卸载清理和提示词探针。

上游许可证见 `vendor/dsh-purge/LICENSE` 与 `THIRD_PARTY_LICENSES.md`。
