# Third-party licenses

## dsh-purge-community 1.7.20

- Source: https://github.com/kingcharleslzy-ai/dsh-purge
- License: MIT
- Copyright (c) 2026 小杨
- Vendored runtime: `vendor/dsh-purge/`
- Original license: `vendor/dsh-purge/LICENSE`
- Original notice: `vendor/dsh-purge/NOTICE.md`

The Dream adapter maps the upstream functionality to Dream capabilities. It does not claim
that DSH host patches, Electron/ASAR replacement, or DSH updater/uninstall behavior are
supported by Dream.
